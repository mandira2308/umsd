#ifndef __H_VERSION_H_
#define __H_VERSION_H_

#ifdef __cplusplus
extern "C" {
#endif

#define MCLI_VERSION "3.0.6"
char *getMCLIVersion();

#ifdef __cplusplus
}
#endif
#endif