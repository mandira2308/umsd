#include <stdio.h>
#include "msdApi.h"


void runCustomizeCode(MSD_U8 devNum)
{
	//Customize test cases here
}
