#include "version.h"

char MCLIVersion[] = MCLI_VERSION;

char *getMCLIVersion()
{
    return MCLIVersion;
}